import React from 'react'
import { Link } from 'react-router-dom';
import logo from './ana111.jpg';

  
function Nav() {


    return (
        <>

                <nav className="navbar">
            <div className="nav-center">
          <div className="nav-header">
            <Link to="/">
              <img src={logo} alt="Analysis" />
            </Link>
            
          </div>
          <ul
             className= "nav-links"
           >
            
            <li>
              <Link to="/tab1">Analysis 1</Link>
            </li>
            <li>
              <Link to="/tab2">Analysis 2</Link>
            </li>
            <li>
              <Link to="/tab3">Analysis 3</Link>
            </li>
          </ul>
        </div>
      </nav>

   
        </>
    )
}

export default Nav

